# APP350_MAPPING_REPORT.md

## Source
Raw `APP-350_v1.1.zip` (official corpus, 350 policies, YAML annotations with `practice` + `modality` fields per segment).

## Mapping rule (approved before running)

| APP-350 practice pattern | OPP-115 category | Decision | Reason |
|---|---|---|---|
| `*_1stParty` | First Party Collection/Use | INCLUDE | Annotator instructions define 1st-party as the app developer itself collecting data — directly matches the OPP-115 category definition |
| `*_3rdParty` | Third Party Sharing/Collection | INCLUDE | Annotator instructions define 3rd-party practices as ad/analytics SDKs collecting or receiving shared data — matches OPP-115's sharing/collection-by-others category |
| `SSO`, `Facebook_SSO` | — | EXCLUDE | No party suffix; genuinely ambiguous whether this is first-party receipt or third-party sharing. Not forced either way. |
| Unannotated segments | — | EXCLUDE | No practice mentioned — nothing to map |
| Data Retention | — | EXCLUDE | No field in APP-350's schema (data type × party × modality) speaks to retention periods |
| Data Security | — | EXCLUDE | No field speaks to security/encryption measures |
| User Choice/Control | — | EXCLUDE | No field speaks to opt-in/opt-out/consent mechanisms |
| Policy Change | — | EXCLUDE | No field speaks to policy-change notices |
| Do Not Track | — | EXCLUDE | No field speaks to DNT signals |
| International and Specific Audiences | — | EXCLUDE | No field speaks to geographic/audience scope |
| User Access, Edit and Deletion | — | EXCLUDE | No field speaks to access/edit/delete rights |
| Other | — | EXCLUDE | Not a meaningful mapping target |

**Modality (PERFORMED / NOT_PERFORMED):** treated as the same OPP-115 topic label in both cases (topic classifier, not stance classifier) — approved decision. Original modality is preserved per-practice in a `modality_detail` field on every converted record, never discarded.

## Totals

| | Count |
|---|---:|
| Total APP-350 segments | 15,507 |
| Unannotated (excluded) | 11,422 |
| Annotated | 4,085 |
| — SSO/Facebook_SSO-only (excluded) | 148 |
| — **Mapped** | **3,937** |
| &nbsp;&nbsp;only First Party Collection/Use | 2,973 |
| &nbsp;&nbsp;only Third Party Sharing/Collection | 535 |
| &nbsp;&nbsp;both (multi-label) | 429 |

Of the 58 distinct raw practice labels in the corpus, all 58 reduce to exactly these two INCLUDE buckets or the SSO EXCLUDE bucket — none were dropped for being unrecognized; every practice label was inspected.

See `app350_to_opp115_mapping.json` for the machine-readable version of this table.
