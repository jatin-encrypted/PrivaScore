# COMBINED_DATASET_ANALYSIS.md — OPP-115 + APP-350 Experiment

## Headline result

| Experiment | Train macro F1 | Val macro F1 | Test macro F1 |
|---|---:|---:|---:|
| OPP-115 only | 0.9022 | 0.7251 | 0.7273 |
| OPP-115 + APP-350 (combined, full test set) | 0.8254 | 0.6518 | 0.6429 |
| OPP-115 + APP-350 (combined, **OPP-115 rows of test set only**) | — | — | **0.7006** |
| APP-350 rows of test set, restricted to its 2 relevant classes only | — | — | 0.8028 |

**The number that matters most is the third row: 0.7006 vs 0.7273.** Both are evaluated on the *identical* 18 held-out OPP-115 policies, so this is the fairest apples-to-apples comparison available. Combining datasets made OPP-115 performance **worse**, not better — a 2.7-point absolute / ~3.7% relative drop.

The raw "combined, full test set" number (0.6429) looks worse still, but a good chunk of that is a measurement artifact, not a real effect — explained below.

## Why the raw combined-test number (0.6429) is partly misleading

APP-350 rows can only ever have `First Party Collection/Use` and/or `Third Party Sharing/Collection` as true labels — the other 8 categories are structurally always 0 for those rows, because APP-350's annotation scheme never encodes them. When you macro-average F1 across all 10 categories on a test set that mixes in ~53% APP-350 rows, any false positive the model makes on those 8 categories for an APP-350 row drags the score down without there being a meaningful "miss" to speak of — the ground truth was mathematically guaranteed to be negative there.

Restricting to just the 2 classes APP-350 rows can actually be scored on, the model does fine there: **0.8858 F1 on First Party, 0.7198 on Third Party** (macro 0.8028). So the model isn't confused by APP-350's mobile-app-policy text — it classifies that text's own two relevant categories reasonably well. The problem isn't APP-350 in isolation; it's what adding it did to the shared model's behavior on OPP-115.

## Per-class comparison on OPP-115's test policies (same 18 policies, both experiments)

| Category | OPP-115-only F1 | Combined-model F1 | Change |
|---|---:|---:|---:|
| First Party Collection/Use | 0.77 | 0.76 | ↓ slight |
| Third Party Sharing/Collection | 0.83 | 0.80 | ↓ |
| User Choice/Control | 0.59 | 0.58 | ↓ slight |
| User Access, Edit and Deletion | 0.67 | 0.67 | flat |
| Data Retention | 0.49 | 0.45 | ↓ |
| Data Security | 0.63 | 0.65 | ↑ slight |
| Policy Change | 0.79 | 0.76 | ↓ |
| Do Not Track | 1.00 | 0.89 | ↓ (n=5, noise-level) |
| International/Specific Audiences | 0.75 | 0.75 | flat |
| Other | 0.75 | 0.69 | ↓ |

## Answering the Phase 12 questions directly

1. **Did the combined dataset improve test macro F1?** No — on the fair (same-policies) comparison, it went from 0.7273 to 0.7006.
2. **Did validation performance improve?** No — 0.7251 → 0.6518 (though the combined-val number mixes sources the same way the raw combined-test number does, so it's subject to the same artifact; the direction is still consistent with the OPP-115-only comparison).
3. **Did the train/validation gap increase or decrease?** Train-val gap: OPP-115-only was 0.9022−0.7251=0.177. Combined was 0.8254−00.6518=0.174. Essentially unchanged — this isn't an overfitting story, it's a *fit-quality* story (see Q8).
4. **Which classes improved?** Only Data Security, marginally (0.63→0.65).
5. **Which classes got worse?** Third Party Sharing/Collection, Policy Change, Data Retention, Other, and — notably — even First Party Collection/Use itself dipped slightly, despite being the exact category APP-350 was supposed to reinforce.
6. **Did APP-350 help rare OPP-115 classes?** No. Data Retention (your worst class) got *worse* (0.49→0.45), and Do Not Track's tiny test set moved in the wrong direction too. This was predictable structurally: APP-350 has zero annotation coverage of these categories, so it cannot teach the model anything about them — it can only ever add training volume to First Party and Third Party, which were already your two best-performing classes.
7. **Did class imbalance improve?** No — it got *worse*. First Party Collection/Use's share of all positive labels in the training set rose from ~40% (OPP-115 alone) to 63% (combined). Adding APP-350 makes the already-dominant classes more dominant, which is the opposite of what would help macro F1.
8. **Did the combined dataset introduce more noise?** More precisely: it introduced *domain shift*, not noise in the sense of bad labels. APP-350 is annotated by a different methodology (single legal expert, mobile-app policies, includes synthetic hand-edited negations in train/val) than OPP-115 (three annotators, website policies). The shared TF-IDF vocabulary and shared per-class logistic-regression weights, learned jointly across both text styles, end up slightly worse-fit to OPP-115's specific phrasing than a model trained on OPP-115 alone.
9. **Is the label mapping broad and trustworthy, or are many APP-350 samples excluded?** The mapping itself is narrow by design and defensible: only 2 of 10 categories, 3,937 of 15,507 raw segments (25%) survive mapping, and everything excluded has a documented, non-invented reason (see `app350_to_opp115_mapping.json`). The mapping quality isn't the problem — the two mapped categories score well *on APP-350's own text* (0.80 macro F1). The problem is that even a clean, honest mapping doesn't help the target task, because it structurally can't touch 8 of 10 categories and dilutes the shared model on the 2 it does touch.
10. **Should we use the combined dataset for the later BERT experiment?** Recommendation: **no, not for training.** The TF-IDF experiment gives a clear, structurally-explained "this doesn't help" result before spending GPU time on BERT. Where APP-350 could still be useful: as a **held-out generalization test** for the OPP-115-trained BERT model on First Party / Third Party specifically (does BERT's contextual understanding transfer to mobile-app-style privacy language better than TF-IDF's bag-of-words did?) — that's a legitimate, cheap follow-up experiment that doesn't require retraining on mixed data.

## Bottom line for your report

This is a genuinely useful negative result, and negative results with a structural explanation (not just "the number went down") are exactly the kind of thing that makes a mini-project report stronger, not weaker. The finding in one sentence: **APP-350's annotation scheme covers only 2 of OPP-115's 10 categories, so combining datasets can only reinforce already-strong classes and dilutes the model's fit to OPP-115's specific phrasing — net effect is a small regression, not the improvement more data is often assumed to bring.**
